/******/ (() => { // webpackBootstrap
/******/ 	"use strict";

;// ./src/background/llm/types.ts
const SYSTEM_PROMPT = `You are ReadingBuddy, a concise AI reading assistant.

When explaining highlighted text:
- Give a SHORT explanation (2-3 sentences max)
- Be direct and clear
- End with a brief question like "Want me to elaborate?" or "Need more detail?"

For follow-up questions, provide more depth if asked.

Use markdown for formatting (**bold**, *italic*, \`code\`).`;

;// ./src/background/llm/ollama.ts

class OllamaProvider {
    constructor(config) {
        this.name = 'Ollama';
        this.host = config.host;
        this.model = config.model;
    }
    async isAvailable() {
        try {
            const response = await fetch(`${this.host}/api/tags`);
            return response.ok;
        }
        catch {
            return false;
        }
    }
    async *generateStream(context, history) {
        const messages = this.buildMessages(context, history);
        const response = await fetch(`${this.host}/api/chat`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: this.model,
                messages,
                stream: true,
            }),
        });
        if (!response.ok) {
            throw new Error(`Ollama error: ${response.statusText}`);
        }
        const reader = response.body?.getReader();
        if (!reader)
            throw new Error('No response body');
        const decoder = new TextDecoder();
        while (true) {
            const { done, value } = await reader.read();
            if (done)
                break;
            const chunk = decoder.decode(value);
            const lines = chunk.split('\n').filter(Boolean);
            for (const line of lines) {
                try {
                    const json = JSON.parse(line);
                    if (json.message?.content) {
                        yield json.message.content;
                    }
                }
                catch {
                    // Skip malformed JSON
                }
            }
        }
    }
    buildMessages(context, history) {
        const userPrompt = `I'm reading a webpage titled "${context.pageTitle}" (${context.pageUrl}).

I highlighted this text:
"${context.selectedText}"

Here's the surrounding context from the page:
${context.surroundingText}

Please explain what this highlighted text means in this context.`;
        const messages = [
            { role: 'system', content: SYSTEM_PROMPT },
            { role: 'user', content: userPrompt },
        ];
        // Add conversation history (skip the first user message as we already included it)
        for (const msg of history.slice(1)) {
            messages.push({ role: msg.role, content: msg.content });
        }
        return messages;
    }
}

;// ./src/background/llm/openai.ts

class OpenAIProvider {
    constructor(config) {
        this.name = 'OpenAI';
        this.apiKey = config.apiKey;
        this.model = config.model;
    }
    async isAvailable() {
        if (!this.apiKey)
            return false;
        try {
            const response = await fetch('https://api.openai.com/v1/models', {
                headers: { Authorization: `Bearer ${this.apiKey}` },
            });
            return response.ok;
        }
        catch {
            return false;
        }
    }
    async *generateStream(context, history) {
        const messages = this.buildMessages(context, history);
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${this.apiKey}`,
            },
            body: JSON.stringify({
                model: this.model,
                messages,
                stream: true,
            }),
        });
        if (!response.ok) {
            const error = await response.text();
            throw new Error(`OpenAI error: ${error}`);
        }
        const reader = response.body?.getReader();
        if (!reader)
            throw new Error('No response body');
        const decoder = new TextDecoder();
        while (true) {
            const { done, value } = await reader.read();
            if (done)
                break;
            const chunk = decoder.decode(value);
            const lines = chunk.split('\n').filter((line) => line.startsWith('data: '));
            for (const line of lines) {
                const data = line.slice(6); // Remove 'data: ' prefix
                if (data === '[DONE]')
                    return;
                try {
                    const json = JSON.parse(data);
                    const content = json.choices?.[0]?.delta?.content;
                    if (content) {
                        yield content;
                    }
                }
                catch {
                    // Skip malformed JSON
                }
            }
        }
    }
    buildMessages(context, history) {
        const userPrompt = `I'm reading a webpage titled "${context.pageTitle}" (${context.pageUrl}).

I highlighted this text:
"${context.selectedText}"

Here's the surrounding context from the page:
${context.surroundingText}

Please explain what this highlighted text means in this context.`;
        const messages = [
            { role: 'system', content: SYSTEM_PROMPT },
            { role: 'user', content: userPrompt },
        ];
        for (const msg of history.slice(1)) {
            messages.push({ role: msg.role, content: msg.content });
        }
        return messages;
    }
}

;// ./src/background/llm/anthropic.ts

class AnthropicProvider {
    constructor(config) {
        this.name = 'Anthropic';
        this.apiKey = config.apiKey;
        this.model = config.model;
    }
    async isAvailable() {
        return !!this.apiKey;
    }
    async *generateStream(context, history) {
        const messages = this.buildMessages(context, history);
        const response = await fetch('https://api.anthropic.com/v1/messages', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-api-key': this.apiKey,
                'anthropic-version': '2023-06-01',
                'anthropic-dangerous-direct-browser-access': 'true',
            },
            body: JSON.stringify({
                model: this.model,
                max_tokens: 1024,
                system: SYSTEM_PROMPT,
                messages,
                stream: true,
            }),
        });
        if (!response.ok) {
            const error = await response.text();
            throw new Error(`Anthropic error: ${error}`);
        }
        const reader = response.body?.getReader();
        if (!reader)
            throw new Error('No response body');
        const decoder = new TextDecoder();
        while (true) {
            const { done, value } = await reader.read();
            if (done)
                break;
            const chunk = decoder.decode(value);
            const lines = chunk.split('\n').filter((line) => line.startsWith('data: '));
            for (const line of lines) {
                const data = line.slice(6);
                try {
                    const json = JSON.parse(data);
                    if (json.type === 'content_block_delta' && json.delta?.text) {
                        yield json.delta.text;
                    }
                }
                catch {
                    // Skip malformed JSON
                }
            }
        }
    }
    buildMessages(context, history) {
        const userPrompt = `I'm reading a webpage titled "${context.pageTitle}" (${context.pageUrl}).

I highlighted this text:
"${context.selectedText}"

Here's the surrounding context from the page:
${context.surroundingText}

Please explain what this highlighted text means in this context.`;
        const messages = [
            { role: 'user', content: userPrompt },
        ];
        for (const msg of history.slice(1)) {
            messages.push({ role: msg.role, content: msg.content });
        }
        return messages;
    }
}

;// ./src/utils/storage.ts
const DEFAULT_SETTINGS = {
    provider: 'ollama',
    ollama: {
        host: 'http://localhost:11434',
        model: '',
    },
    openai: {
        apiKey: '',
        model: 'gpt-4o-mini',
    },
    anthropic: {
        apiKey: '',
        model: 'claude-sonnet-4-20250514',
    },
};
const DEFAULT_STATE = {
    onboarded: false,
    enabled: true,
};
const storage = {
    async get(key, defaultValue) {
        const result = await chrome.storage.local.get(key);
        return result[key] ?? defaultValue;
    },
    async set(key, value) {
        await chrome.storage.local.set({ [key]: value });
    },
    async getSettings() {
        return this.get('settings', DEFAULT_SETTINGS);
    },
    async saveSettings(settings) {
        await this.set('settings', settings);
    },
    async getState() {
        return this.get('appState', DEFAULT_STATE);
    },
    async setState(state) {
        const current = await this.getState();
        await this.set('appState', { ...current, ...state });
    },
    async isOnboarded() {
        const state = await this.getState();
        return state.onboarded;
    },
    async isEnabled() {
        const state = await this.getState();
        return state.enabled;
    },
};

;// ./src/background/llm/index.ts




async function getLLMProvider() {
    const settings = await storage.getSettings();
    switch (settings.provider) {
        case 'ollama':
            return new OllamaProvider(settings.ollama);
        case 'openai':
            return new OpenAIProvider(settings.openai);
        case 'anthropic':
            return new AnthropicProvider(settings.anthropic);
        default:
            return new OllamaProvider(settings.ollama);
    }
}




;// ./src/background/service-worker.ts


// Open onboarding page on install
chrome.runtime.onInstalled.addListener(async (details) => {
    if (details.reason === 'install') {
        // Check if already onboarded (shouldn't be on fresh install, but just in case)
        const isOnboarded = await storage.isOnboarded();
        if (!isOnboarded) {
            chrome.tabs.create({
                url: chrome.runtime.getURL('onboarding/onboarding.html'),
            });
        }
    }
});
// Also check on startup (in case user closes onboarding without completing)
chrome.runtime.onStartup.addListener(async () => {
    const isOnboarded = await storage.isOnboarded();
    if (!isOnboarded) {
        chrome.tabs.create({
            url: chrome.runtime.getURL('onboarding/onboarding.html'),
        });
    }
});
// Handle port connections for streaming
chrome.runtime.onConnect.addListener((port) => {
    console.log('Port connected:', port.name);
    if (port.name !== 'reading-buddy-stream')
        return;
    port.onMessage.addListener(async (msg) => {
        console.log('Received message:', msg.type);
        if (msg.type === 'EXPLAIN_TEXT') {
            console.log('Context:', msg.payload.context.selectedText);
            await handleExplainText(port, msg.payload.context, msg.payload.history);
        }
    });
});
// Handle one-off messages
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === 'GET_SETTINGS') {
        storage.getSettings().then(sendResponse);
        return true;
    }
    if (msg.type === 'GET_STATE') {
        storage.getState().then(sendResponse);
        return true;
    }
    if (msg.type === 'TEST_CONNECTION') {
        testConnection(msg.provider).then(sendResponse);
        return true;
    }
    return false;
});
async function handleExplainText(port, context, history) {
    try {
        // Check if enabled
        const isEnabled = await storage.isEnabled();
        if (!isEnabled) {
            port.postMessage({ type: 'STREAM_ERROR', error: 'ReadingBuddy is disabled' });
            return;
        }
        console.log('handleExplainText called');
        const provider = await getLLMProvider();
        console.log('Got provider:', provider.name);
        for await (const chunk of provider.generateStream(context, history)) {
            console.log('Chunk:', chunk.slice(0, 50));
            port.postMessage({ type: 'STREAM_CHUNK', content: chunk });
        }
        console.log('Stream complete');
        port.postMessage({ type: 'STREAM_END' });
    }
    catch (error) {
        console.error('Error in handleExplainText:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        port.postMessage({ type: 'STREAM_ERROR', error: errorMessage });
    }
}
async function testConnection(providerName) {
    try {
        const settings = await storage.getSettings();
        let provider;
        switch (providerName) {
            case 'ollama':
                provider = new OllamaProvider(settings.ollama);
                break;
            case 'openai':
                provider = new OpenAIProvider(settings.openai);
                break;
            case 'anthropic':
                provider = new AnthropicProvider(settings.anthropic);
                break;
            default:
                return { success: false, error: 'Unknown provider' };
        }
        const available = await provider.isAvailable();
        return { success: available, error: available ? undefined : 'Connection failed' };
    }
    catch (error) {
        return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
}
console.log('ReadingBuddy service worker loaded');

/******/ })()
;
//# sourceMappingURL=service-worker.js.map