/******/ (() => { // webpackBootstrap
/******/ 	"use strict";

;// ./src/utils/storage.ts
const DEFAULT_SETTINGS = {
    provider: 'ollama',
    ollama: {
        host: 'http://localhost:11434',
        model: '',
    },
    openai: {
        apiKey: '',
        model: 'gpt-4o-mini',
    },
    anthropic: {
        apiKey: '',
        model: 'claude-sonnet-4-20250514',
    },
};
const DEFAULT_STATE = {
    onboarded: false,
    enabled: true,
};
const storage = {
    async get(key, defaultValue) {
        const result = await chrome.storage.local.get(key);
        return result[key] ?? defaultValue;
    },
    async set(key, value) {
        await chrome.storage.local.set({ [key]: value });
    },
    async getSettings() {
        return this.get('settings', DEFAULT_SETTINGS);
    },
    async saveSettings(settings) {
        await this.set('settings', settings);
    },
    async getState() {
        return this.get('appState', DEFAULT_STATE);
    },
    async setState(state) {
        const current = await this.getState();
        await this.set('appState', { ...current, ...state });
    },
    async isOnboarded() {
        const state = await this.getState();
        return state.onboarded;
    },
    async isEnabled() {
        const state = await this.getState();
        return state.enabled;
    },
};

;// ./src/onboarding/onboarding.ts


// Steps
const stepWelcome = document.getElementById('step-welcome');
const stepProvider = document.getElementById('step-provider');
const stepOllama = document.getElementById('step-ollama');
const stepOpenai = document.getElementById('step-openai');
const stepAnthropic = document.getElementById('step-anthropic');
const stepSuccess = document.getElementById('step-success');
// Buttons
const btnGetStarted = document.getElementById('btn-get-started');
const btnBackOllama = document.getElementById('btn-back-ollama');
const btnBackOpenai = document.getElementById('btn-back-openai');
const btnBackAnthropic = document.getElementById('btn-back-anthropic');
const btnTestOllama = document.getElementById('btn-test-ollama');
const btnTestOpenai = document.getElementById('btn-test-openai');
const btnTestAnthropic = document.getElementById('btn-test-anthropic');
const btnFinish = document.getElementById('btn-finish');
const refreshModelsBtn = document.getElementById('refresh-models');
// Inputs
const ollamaHost = document.getElementById('ollama-host');
const ollamaModel = document.getElementById('ollama-model');
const openaiKey = document.getElementById('openai-key');
const openaiModel = document.getElementById('openai-model');
const anthropicKey = document.getElementById('anthropic-key');
const anthropicModel = document.getElementById('anthropic-model');
// Status
const ollamaStatus = document.getElementById('ollama-status');
const openaiStatus = document.getElementById('openai-status');
const anthropicStatus = document.getElementById('anthropic-status');
// Provider cards
const providerCards = document.querySelectorAll('.provider-card');
let selectedProvider = 'ollama';
let connectionTested = false;
// Navigation
function showStep(step) {
    [stepWelcome, stepProvider, stepOllama, stepOpenai, stepAnthropic, stepSuccess].forEach(s => {
        s.classList.add('hidden');
    });
    step.classList.remove('hidden');
}
// Event Listeners
btnGetStarted.addEventListener('click', () => showStep(stepProvider));
providerCards.forEach(card => {
    card.addEventListener('click', () => {
        selectedProvider = card.getAttribute('data-provider');
        providerCards.forEach(c => c.classList.remove('selected'));
        card.classList.add('selected');
        connectionTested = false;
        // Navigate to config step
        setTimeout(() => {
            switch (selectedProvider) {
                case 'ollama':
                    showStep(stepOllama);
                    refreshOllamaModels();
                    break;
                case 'openai':
                    showStep(stepOpenai);
                    break;
                case 'anthropic':
                    showStep(stepAnthropic);
                    break;
            }
        }, 200);
    });
});
btnBackOllama.addEventListener('click', () => showStep(stepProvider));
btnBackOpenai.addEventListener('click', () => showStep(stepProvider));
btnBackAnthropic.addEventListener('click', () => showStep(stepProvider));
refreshModelsBtn.addEventListener('click', refreshOllamaModels);
btnTestOllama.addEventListener('click', () => testConnection('ollama'));
btnTestOpenai.addEventListener('click', () => testConnection('openai'));
btnTestAnthropic.addEventListener('click', () => testConnection('anthropic'));
btnFinish.addEventListener('click', async () => {
    await storage.setState({ onboarded: true });
    window.close();
});
// Ollama model refresh
async function refreshOllamaModels() {
    try {
        const host = ollamaHost.value || 'http://localhost:11434';
        const response = await fetch(`${host}/api/tags`);
        if (!response.ok) {
            throw new Error('Failed to fetch models');
        }
        const data = await response.json();
        const models = data.models || [];
        ollamaModel.innerHTML = '';
        if (models.length === 0) {
            const option = document.createElement('option');
            option.value = '';
            option.textContent = 'No models found';
            ollamaModel.appendChild(option);
            return;
        }
        models.forEach((model) => {
            const option = document.createElement('option');
            option.value = model.name;
            option.textContent = model.name;
            ollamaModel.appendChild(option);
        });
        showStatus(ollamaStatus, `Found ${models.length} model${models.length === 1 ? '' : 's'}`, 'success');
    }
    catch {
        ollamaModel.innerHTML = '<option value="">Could not connect</option>';
        showStatus(ollamaStatus, 'Could not connect to Ollama. Is it running?', 'error');
    }
}
// Connection test
async function testConnection(provider) {
    const statusEl = provider === 'ollama' ? ollamaStatus :
        provider === 'openai' ? openaiStatus : anthropicStatus;
    const btn = provider === 'ollama' ? btnTestOllama :
        provider === 'openai' ? btnTestOpenai : btnTestAnthropic;
    // Save settings first
    await saveCurrentSettings();
    showStatus(statusEl, 'Testing connection...', 'loading');
    btn.disabled = true;
    const result = await chrome.runtime.sendMessage({
        type: 'TEST_CONNECTION',
        provider,
    });
    btn.disabled = false;
    if (result.success) {
        showStatus(statusEl, 'Connection successful!', 'success');
        connectionTested = true;
        // Show success after short delay
        setTimeout(() => {
            showStep(stepSuccess);
        }, 1000);
    }
    else {
        showStatus(statusEl, result.error || 'Connection failed', 'error');
    }
}
function showStatus(el, message, type) {
    el.textContent = message;
    el.className = `status-box show ${type}`;
}
async function saveCurrentSettings() {
    const settings = {
        provider: selectedProvider,
        ollama: {
            host: ollamaHost.value || 'http://localhost:11434',
            model: ollamaModel.value,
        },
        openai: {
            apiKey: openaiKey.value,
            model: openaiModel.value,
        },
        anthropic: {
            apiKey: anthropicKey.value,
            model: anthropicModel.value,
        },
    };
    await storage.saveSettings(settings);
}
// Load any existing settings
async function loadExistingSettings() {
    const settings = await storage.getSettings();
    ollamaHost.value = settings.ollama.host;
    openaiKey.value = settings.openai.apiKey;
    openaiModel.value = settings.openai.model;
    anthropicKey.value = settings.anthropic.apiKey;
    anthropicModel.value = settings.anthropic.model;
}
loadExistingSettings();

/******/ })()
;
//# sourceMappingURL=onboarding.js.map