/******/ (() => { // webpackBootstrap
/******/ 	"use strict";

;// ./src/utils/storage.ts
const DEFAULT_SETTINGS = {
    provider: 'ollama',
    ollama: {
        host: 'http://localhost:11434',
        model: '',
    },
    openai: {
        apiKey: '',
        model: 'gpt-4o-mini',
    },
    anthropic: {
        apiKey: '',
        model: 'claude-sonnet-4-20250514',
    },
};
const DEFAULT_STATE = {
    onboarded: false,
    enabled: true,
};
const storage = {
    async get(key, defaultValue) {
        const result = await chrome.storage.local.get(key);
        return result[key] ?? defaultValue;
    },
    async set(key, value) {
        await chrome.storage.local.set({ [key]: value });
    },
    async getSettings() {
        return this.get('settings', DEFAULT_SETTINGS);
    },
    async saveSettings(settings) {
        await this.set('settings', settings);
    },
    async getState() {
        return this.get('appState', DEFAULT_STATE);
    },
    async setState(state) {
        const current = await this.getState();
        await this.set('appState', { ...current, ...state });
    },
    async isOnboarded() {
        const state = await this.getState();
        return state.onboarded;
    },
    async isEnabled() {
        const state = await this.getState();
        return state.enabled;
    },
};

;// ./src/popup/popup.ts


const statusEl = document.getElementById('status');
const toggleEnabled = document.getElementById('toggle-enabled');
const providerNameEl = document.getElementById('provider-name');
const btnSettings = document.getElementById('btn-settings');
const btnTest = document.getElementById('btn-test');
async function init() {
    // Load current state
    const state = await storage.getState();
    const settings = await storage.getSettings();
    toggleEnabled.checked = state.enabled;
    updateProviderDisplay(settings.provider);
    if (!state.enabled) {
        updateStatus('disabled', 'Disabled');
    }
    else {
        // Test connection on load
        testConnection(settings.provider);
    }
}
function updateStatus(type, text) {
    statusEl.className = `status ${type}`;
    statusEl.textContent = text;
}
function updateProviderDisplay(provider) {
    const names = {
        ollama: 'Ollama (Local)',
        openai: 'OpenAI',
        anthropic: 'Anthropic',
    };
    providerNameEl.textContent = names[provider] || provider;
}
async function testConnection(provider) {
    updateStatus('disconnected', 'Testing...');
    const result = await chrome.runtime.sendMessage({
        type: 'TEST_CONNECTION',
        provider,
    });
    if (result.success) {
        updateStatus('connected', 'Connected');
    }
    else {
        updateStatus('disconnected', 'Disconnected');
    }
}
// Toggle enabled state
toggleEnabled.addEventListener('change', async () => {
    const enabled = toggleEnabled.checked;
    await storage.setState({ enabled });
    if (enabled) {
        const settings = await storage.getSettings();
        testConnection(settings.provider);
    }
    else {
        updateStatus('disabled', 'Disabled');
    }
    // Notify all tabs to update
    chrome.tabs.query({}, (tabs) => {
        tabs.forEach((tab) => {
            if (tab.id) {
                chrome.tabs.sendMessage(tab.id, { type: 'ENABLED_CHANGED', enabled }).catch(() => {
                    // Tab might not have content script
                });
            }
        });
    });
});
// Settings button
btnSettings.addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
});
// Test button
btnTest.addEventListener('click', async () => {
    const settings = await storage.getSettings();
    testConnection(settings.provider);
});
init();

/******/ })()
;
//# sourceMappingURL=popup.js.map