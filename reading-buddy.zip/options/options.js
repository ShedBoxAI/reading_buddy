/******/ (() => { // webpackBootstrap
/******/ 	"use strict";

;// ./src/utils/storage.ts
const DEFAULT_SETTINGS = {
    provider: 'ollama',
    ollama: {
        host: 'http://localhost:11434',
        model: '',
    },
    openai: {
        apiKey: '',
        model: 'gpt-4o-mini',
    },
    anthropic: {
        apiKey: '',
        model: 'claude-sonnet-4-20250514',
    },
};
const DEFAULT_STATE = {
    onboarded: false,
    enabled: true,
};
const storage = {
    async get(key, defaultValue) {
        const result = await chrome.storage.local.get(key);
        return result[key] ?? defaultValue;
    },
    async set(key, value) {
        await chrome.storage.local.set({ [key]: value });
    },
    async getSettings() {
        return this.get('settings', DEFAULT_SETTINGS);
    },
    async saveSettings(settings) {
        await this.set('settings', settings);
    },
    async getState() {
        return this.get('appState', DEFAULT_STATE);
    },
    async setState(state) {
        const current = await this.getState();
        await this.set('appState', { ...current, ...state });
    },
    async isOnboarded() {
        const state = await this.getState();
        return state.onboarded;
    },
    async isEnabled() {
        const state = await this.getState();
        return state.enabled;
    },
};

;// ./src/options/options.ts


// Elements
const providerRadios = document.querySelectorAll('input[name="provider"]');
const ollamaSettings = document.getElementById('ollama-settings');
const openaiSettings = document.getElementById('openai-settings');
const anthropicSettings = document.getElementById('anthropic-settings');
const ollamaHost = document.getElementById('ollama-host');
const ollamaModel = document.getElementById('ollama-model');
const refreshModelsBtn = document.getElementById('refresh-models');
const testOllamaBtn = document.getElementById('test-ollama');
const ollamaStatus = document.getElementById('ollama-status');
const openaiKey = document.getElementById('openai-key');
const openaiModel = document.getElementById('openai-model');
const testOpenaiBtn = document.getElementById('test-openai');
const openaiStatus = document.getElementById('openai-status');
const anthropicKey = document.getElementById('anthropic-key');
const anthropicModel = document.getElementById('anthropic-model');
const testAnthropicBtn = document.getElementById('test-anthropic');
const anthropicStatus = document.getElementById('anthropic-status');
const saveBtn = document.getElementById('save');
const saveStatus = document.getElementById('save-status');
// Load settings on page load
document.addEventListener('DOMContentLoaded', loadSettings);
// Provider switching
providerRadios.forEach((radio) => {
    radio.addEventListener('change', () => {
        updateVisibleSettings(radio.value);
    });
});
// Event listeners
refreshModelsBtn.addEventListener('click', refreshOllamaModels);
testOllamaBtn.addEventListener('click', () => testConnection('ollama'));
testOpenaiBtn.addEventListener('click', () => testConnection('openai'));
testAnthropicBtn.addEventListener('click', () => testConnection('anthropic'));
saveBtn.addEventListener('click', saveSettings);
async function loadSettings() {
    const settings = await storage.getSettings();
    // Set provider
    const providerRadio = document.querySelector(`input[name="provider"][value="${settings.provider}"]`);
    if (providerRadio) {
        providerRadio.checked = true;
        updateVisibleSettings(settings.provider);
    }
    // Ollama
    ollamaHost.value = settings.ollama.host;
    ollamaModel.value = settings.ollama.model;
    // OpenAI
    openaiKey.value = settings.openai.apiKey;
    openaiModel.value = settings.openai.model;
    // Anthropic
    anthropicKey.value = settings.anthropic.apiKey;
    anthropicModel.value = settings.anthropic.model;
    // Try to load Ollama models
    refreshOllamaModels();
}
function updateVisibleSettings(provider) {
    ollamaSettings.classList.toggle('hidden', provider !== 'ollama');
    openaiSettings.classList.toggle('hidden', provider !== 'openai');
    anthropicSettings.classList.toggle('hidden', provider !== 'anthropic');
}
async function refreshOllamaModels() {
    try {
        const host = ollamaHost.value || 'http://localhost:11434';
        const response = await fetch(`${host}/api/tags`);
        if (!response.ok) {
            throw new Error('Failed to fetch models');
        }
        const data = await response.json();
        const models = data.models || [];
        // Save current selection
        const currentModel = ollamaModel.value;
        // Clear and repopulate
        ollamaModel.innerHTML = '';
        models.forEach((model) => {
            const option = document.createElement('option');
            option.value = model.name;
            option.textContent = model.name;
            ollamaModel.appendChild(option);
        });
        // Restore selection if still available
        if (models.some((m) => m.name === currentModel)) {
            ollamaModel.value = currentModel;
        }
        ollamaStatus.textContent = `Found ${models.length} models`;
        ollamaStatus.className = 'status-message success';
    }
    catch (error) {
        ollamaStatus.textContent = 'Could not connect to Ollama';
        ollamaStatus.className = 'status-message error';
    }
}
async function testConnection(provider) {
    // First save current values
    await saveSettingsQuiet();
    const statusEl = provider === 'ollama' ? ollamaStatus :
        provider === 'openai' ? openaiStatus : anthropicStatus;
    statusEl.textContent = 'Testing...';
    statusEl.className = 'status-message';
    const result = await chrome.runtime.sendMessage({
        type: 'TEST_CONNECTION',
        provider,
    });
    if (result.success) {
        statusEl.textContent = 'Connection successful!';
        statusEl.className = 'status-message success';
    }
    else {
        statusEl.textContent = result.error || 'Connection failed';
        statusEl.className = 'status-message error';
    }
}
async function saveSettingsQuiet() {
    const provider = document.querySelector('input[name="provider"]:checked')?.value;
    const settings = {
        provider,
        ollama: {
            host: ollamaHost.value,
            model: ollamaModel.value,
        },
        openai: {
            apiKey: openaiKey.value,
            model: openaiModel.value,
        },
        anthropic: {
            apiKey: anthropicKey.value,
            model: anthropicModel.value,
        },
    };
    await storage.saveSettings(settings);
}
async function saveSettings() {
    await saveSettingsQuiet();
    saveStatus.textContent = 'Settings saved!';
    setTimeout(() => {
        saveStatus.textContent = '';
    }, 2000);
}

/******/ })()
;
//# sourceMappingURL=options.js.map